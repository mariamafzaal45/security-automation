#!/usr/bin/env python3
import argparse, csv, json, os, re, time
from pathlib import Path
from datetime import datetime, timezone

CACHE_FILE = Path("cache.json")
CONFIG_FILE = Path("config.yaml")

def now():
    return datetime.now(timezone.utc).isoformat()

def indicator_type(i):
    if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", i): return "ipv4"
    if re.fullmatch(r"[A-Fa-f0-9]{32}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{64}", i): return "hash"
    if i.startswith(("http://","https://")): return "url"
    if re.fullmatch(r"[A-Za-z0-9.-]+\.[A-Za-z]{2,}", i): return "domain"
    return "unknown"

def load_cache():
    try: return json.loads(CACHE_FILE.read_text())
    except Exception: return {}

def save_cache(c):
    CACHE_FILE.write_text(json.dumps(c, indent=2))

def sample_result(indicator):
    t = indicator_type(indicator)
    return {
        "indicator": indicator, "type": t, "timestamp": now(),
        "virustotal": {"status": "not_configured", "malicious": 0},
        "abuseipdb": {"status": "not_configured", "confidence": 0},
        "otx": {"status": "not_configured", "pulses": 0},
        "risk_score": 0, "confidence": 0,
        "note": "Configure API keys to enable live enrichment."
    }

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--indicator")
    p.add_argument("--input-file")
    p.add_argument("--format", choices=["table","json","csv"], default="table")
    args = p.parse_args()

    indicators = []
    if args.indicator: indicators.append(args.indicator.strip())
    if args.input_file:
        with open(args.input_file, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                value = row.get("indicator") or row.get("IOC") or next(iter(row.values()))
                indicators.append(value.strip())

    if not indicators:
        p.error("Use --indicator or --input-file")

    cache = load_cache()
    results = []
    for i in dict.fromkeys(indicators):
        if i in cache:
            result = cache[i]
        else:
            result = sample_result(i)
            cache[i] = result
        results.append(result)
        time.sleep(0.1)
    save_cache(cache)

    if args.format == "json":
        print(json.dumps(results, indent=2))
    elif args.format == "csv":
        writer = csv.DictWriter(open("enrichment_results.csv","w",newline=""),
                                fieldnames=["indicator","type","risk_score","confidence"])
        writer.writeheader()
        for r in results:
            writer.writerow({k:r.get(k) for k in writer.fieldnames})
        print("Saved enrichment_results.csv")
    else:
        print(f"{'Indicator':35} {'Type':10} {'Risk':5} {'Confidence':10}")
        print("-"*65)
        for r in results:
            print(f"{r['indicator']:35} {r['type']:10} {r['risk_score']:5} {r['confidence']:10}")

if __name__ == "__main__":
    main()
