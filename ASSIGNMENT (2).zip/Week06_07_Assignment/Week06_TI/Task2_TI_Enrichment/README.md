# TI Enrichment Engine
Install: `pip install -r requirements.txt`
Configure API keys in your local environment/configuration.
Run:
`python ti_enricher.py --indicator 8.8.8.8`
`python ti_enricher.py --input-file sample_indicators.csv`
`python ti_enricher.py --indicator 8.8.8.8 --format json`
The included starter implementation uses safe sample/no-key mode; live provider calls should be enabled only with valid credentials and current API documentation.
