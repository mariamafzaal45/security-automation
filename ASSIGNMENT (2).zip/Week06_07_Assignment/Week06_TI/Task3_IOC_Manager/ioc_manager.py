#!/usr/bin/env python3
import argparse, csv, json
from datetime import datetime, timedelta, timezone
from pathlib import Path

DB=Path("ioc_database.json")
def load():
    try:return json.loads(DB.read_text())
    except:return {}
def save(x):DB.write_text(json.dumps(x,indent=2))
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--add-file"); p.add_argument("--update-all",action="store_true")
    p.add_argument("--expire-check",action="store_true"); p.add_argument("--export-blocklist",action="store_true")
    p.add_argument("--list",action="store_true")
    a=p.parse_args(); db=load()
    if a.add_file:
        with open(a.add_file) as f:
            for row in csv.DictReader(f):
                i=row.get("indicator")
                if i:
                    db[i]={"indicator":i,"first_seen":datetime.now(timezone.utc).isoformat(),
                           "last_seen":datetime.now(timezone.utc).isoformat(),
                           "expiration":(datetime.now(timezone.utc)+timedelta(days=30)).isoformat(),
                           "confidence":0,"risk_score":0,"status":"active","source_diversity":0}
    if a.expire_check:
        now=datetime.now(timezone.utc)
        for x in db.values():
            try:
                if datetime.fromisoformat(x["expiration"]) < now:x["status"]="expired"
            except: pass
    if a.export_blocklist:
        Path("blocklist.txt").write_text("\n".join(x["indicator"] for x in db.values() if x.get("status")=="active"))
    if a.list:
        for x in db.values():print(x)
    save(db)
if __name__=="__main__":main()
