# THE ARZENS GCR Week 06–07 Assignment
Complete submission package for Threat Intelligence Automation and Infrastructure as Code Security.
See each task folder for reports, source code, configuration, and sample outputs.
