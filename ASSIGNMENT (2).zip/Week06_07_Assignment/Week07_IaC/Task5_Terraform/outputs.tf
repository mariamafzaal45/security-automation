output "vpc_id" { value=aws_vpc.main.id }
output "subnet_id" { value=aws_subnet.public.id }
output "security_group_id" { value=aws_security_group.web.id }
output "s3_bucket" { value=aws_s3_bucket.secure.bucket }
