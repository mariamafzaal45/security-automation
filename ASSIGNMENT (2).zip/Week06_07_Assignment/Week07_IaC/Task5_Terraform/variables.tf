variable "aws_region" { type=string; default="us-east-1" }
variable "project" { type=string; default="gcr-week07" }
variable "vpc_cidr" { type=string; default="10.20.0.0/16" }
variable "subnet_cidr" { type=string; default="10.20.1.0/24" }
variable "ssh_cidr" { type=string; description="Trusted CIDR for SSH"; default="10.20.0.0/16" }
variable "bucket_name" { type=string; description="Globally unique S3 bucket name" }
