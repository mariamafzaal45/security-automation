# Secure Terraform Infrastructure
Configure AWS credentials through the AWS CLI/environment, never in Terraform files.
Run:
terraform init
terraform fmt
terraform validate
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
terraform destroy -var-file=terraform.tfvars

The S3 bucket is private, encrypted and versioned. SSH is restricted by `ssh_cidr`.
Before using a remote backend, bootstrap the backend bucket and configure encryption/locking according to current Terraform and AWS documentation.
