terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}
provider "aws" { region = var.aws_region }

resource "aws_vpc" "main" {
  cidr_block = var.vpc_cidr
  tags = { Name = "${var.project}-vpc" }
}
resource "aws_subnet" "public" {
  vpc_id = aws_vpc.main.id
  cidr_block = var.subnet_cidr
  map_public_ip_on_launch = true
}
resource "aws_internet_gateway" "igw" { vpc_id = aws_vpc.main.id }
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id
  route { cidr_block="0.0.0.0/0"; gateway_id=aws_internet_gateway.igw.id }
}
resource "aws_route_table_association" "public" {
  subnet_id=aws_subnet.public.id
  route_table_id=aws_route_table.public.id
}
resource "aws_security_group" "web" {
  name="${var.project}-sg"; vpc_id=aws_vpc.main.id
  ingress { from_port=22; to_port=22; protocol="tcp"; cidr_blocks=[var.ssh_cidr] }
  ingress { from_port=80; to_port=80; protocol="tcp"; cidr_blocks=["0.0.0.0/0"] }
  ingress { from_port=443; to_port=443; protocol="tcp"; cidr_blocks=["0.0.0.0/0"] }
  egress { from_port=0; to_port=0; protocol="-1"; cidr_blocks=["0.0.0.0/0"] }
}
resource "aws_s3_bucket" "secure" { bucket = var.bucket_name }
resource "aws_s3_bucket_public_access_block" "secure" {
  bucket=aws_s3_bucket.secure.id
  block_public_acls=true; block_public_policy=true
  ignore_public_acls=true; restrict_public_buckets=true
}
resource "aws_s3_bucket_server_side_encryption_configuration" "secure" {
  bucket=aws_s3_bucket.secure.id
  rule { apply_server_side_encryption_by_default { sse_algorithm="AES256" } }
}
resource "aws_s3_bucket_versioning" "secure" {
  bucket=aws_s3_bucket.secure.id
  versioning_configuration { status="Enabled" }
}
