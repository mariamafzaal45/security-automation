# Ansible Hardening
Update `hosts.ini` with your test server and SSH settings.

Dry run:
`ansible-playbook site.yml --check --diff`

Run:
`ansible-playbook site.yml`

Security-only:
`ansible-playbook security.yml`

The roles are designed for idempotent configuration. Test in a disposable VM first and maintain a second SSH session to avoid locking yourself out.
